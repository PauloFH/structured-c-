// Paulo Roberto Fernandes Holanda
#include <iostream>
using namespace std;

int main() {
	float a = 49678.54214622;
	float b = 17.13333333;
	float c = 2.321467457;
	float d = 54.21462243;
	float e = 32.55732664;
	cout << fixed;
	cout.precision(8);
	cout << a << endl;
	cout << b << endl;
	cout << c << endl;
	cout << d << endl;
	cout << e << endl;

}