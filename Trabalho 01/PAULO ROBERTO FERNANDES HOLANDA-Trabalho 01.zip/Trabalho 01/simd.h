unsigned int Armazena(unsigned char a, unsigned char b, unsigned char c, unsigned char d);
//deve receber 4 valores na faixa de 0 a 255 (8 bits) e retornar um valor de 32 bits contendo os 4 valores.
unsigned char Primeiro(unsigned int a);
//deve receber um valor de 32 bits e retornar o valor armazenado no primeiro bloco de 8 bits.
unsigned char Segundo(unsigned int a);
//deve receber um valor de 32 bits e retornar o valor armazenado no segundo bloco de 8 bits.
unsigned char Terceiro(unsigned int a);
//deve receber um valor de 32 bits e retornar o valor armazenado no terceiro bloco de 8 bits.
unsigned char Quarto(unsigned int a);
//deve receber um valor de 32 bits e retornar o valor armazenado no quarto bloco de 8 bits.
unsigned int Soma(unsigned int a, unsigned int b);
//deve receber dois valores de 32 bits e retornar um valor de 32 bits com o resultado das somas individuais de cada valor de 8 bits.
unsigned int Mult(unsigned int a, unsigned int b);
//deve receber dois valores de 32 bits e retornar um valor de 32 bits com o resultado da multiplica��o individual de cada valor de 8 bits.