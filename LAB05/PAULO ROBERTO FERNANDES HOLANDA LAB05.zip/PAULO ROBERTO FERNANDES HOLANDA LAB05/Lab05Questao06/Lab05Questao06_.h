//Paulo Roberto Fernandes Holanda
double tt(double y, double x);
double vet(int x, int y);
