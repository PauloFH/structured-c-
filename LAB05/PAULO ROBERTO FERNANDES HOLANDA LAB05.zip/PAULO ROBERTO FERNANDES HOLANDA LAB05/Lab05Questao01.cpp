//Paulo Roberto Fernandes Holanda
#include <iostream>
#include <cmath>

int main() {
	system("chcp 1252 > nul");
	int x; 
	x = 1;
	/*Nessa primeira � alocado espa�o para X sem definir valor, deixando vazio e s� ap�s � inserido valor.
	esse modelo � muito usado pelo fato de organiza��o.*/

	int y = 1;
	/*Embora funcional n�o � recomendado pelo fato de prejudicar a organiza��o e a leitura do c�digo caso seja grande*/

}
