//Paulo Roberto Fernandes Holanda
#include <iostream>
using namespace std;
enum sem { SEG, TER, QUA, QUI, SEX, SAB, DOM };
int main()
{
	system("chcp 1252 > nul");
	char semana[7][10] ={
	"Domingo", "Segunda", "Ter�a", "Quarta", "Quinta", "Sexta", "Sabado"
	};
	for (sem ind = SEG; ind <= DOM; ind = sem(ind + 1))
		cout << semana[ind] << endl;
	return 0;
}