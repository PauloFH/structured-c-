//Paulo Roberto Fernandes Holanda
#include <iostream>
using namespace std;
	int main() {
	system("chcp 850 > nul");
	cout << "\n\t\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB";
	cout << "\n\t\xBA                     \xBA";
	cout << "\n\t\xBA                     \xBA";
	cout << "\n\t\xBA                     \xBA"; 
	cout << "\n\t\xBA                     \xBA";
	cout << "\n\t\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC";
	cout << "\n\n";
}