//Paulo Roberto Fernandes Holanda
#include <iostream>
using namespace std;

int main(void) {
	cout << "C\n	+\n\n		+";
}