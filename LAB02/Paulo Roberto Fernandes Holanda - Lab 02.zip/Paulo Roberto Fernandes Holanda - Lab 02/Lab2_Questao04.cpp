//Paulo Roberto Fernandes Holanda
#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    cout << "Estou aprendendo: ";
    cout << argv[1];
    cout << "/";
    cout << argv[3];
    cout << "!";
}