//Paulo Roberto Fernandes Holanda
#include <iostream>
using namespace std;

struct Pessoa{
	char nome[15];
	int idade;
	enum sexo{masculino, feminino};
};
int main() {
	system("chcp 1252 > nul");
	Pessoa  RePessoas new [];
	do {
		cout << "Registro de pessoas \n digite nome: ";
		while (RePessoas->nome != "fim") {
			cout << "Digite idade: ";

		}
		while (RePessoas.nome != "fim")
		{

		}
	}
}