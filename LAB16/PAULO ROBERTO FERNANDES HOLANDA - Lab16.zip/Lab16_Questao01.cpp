//Paulo Roberto Fernandes Holanda
#include <iostream>
#include <cstring>
using namespace std;

int main() {
	system("chcp 1252 > nul");

	char player[20]{};
	int len{}, trust{};
	cout << "Digite jogador/time:";
	cin >> player;
	len = strlen(player);
	cout << "O nome do jogador tem ";
	for (int i = 0; i <= len; i++) {
		if (player[i] == '/') {
			cout << (i) << " Letras" << endl;
			trust = i+1;
			i = len;
		}
	}
	cout << "O seu time � o ";
	for (int i = trust; i <= len; i++) {
		cout << player[i];
	}
	cout << ".";
}