//Paulo Roberto Fernandes Holanda
#include <iostream>
#include <cstring>
using namespace std;

int main() {
	system("chcp 1252 > nul");
	int x{}, sm1{}, sm2{}, df{};
	cout << "tamanho: ";
	cin >> x;
	cout << "A  diferen�a da soma dos quadrados dos " << x << " primeiros n�meros naturais e o quadrado da soma �: ";
	for (int i = 0; i <= x; i++) {
		sm1 += pow(i, 2);
		}
	for (int i = 0; i <= x; i++) {
		sm2 += i;
	}
	sm2 = pow(sm2, 2);
	df = sm2 - sm1;
		cout << df;

}
